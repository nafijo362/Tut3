public class TestCode {
    public static void main(String[] args) {
        ProductDatabase productDatabase = new ProductDatabase("product_data.txt");
        Display display = new Display();
        CashRegister cashRegister = new CashRegister(productDatabase, display);
        Keyboard keyboard = new Keyboard(cashRegister);
        keyboard.enterProductID();
    }
}

