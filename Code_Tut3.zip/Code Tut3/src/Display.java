public class Display {
    public void showProductInfo(Product product) {
        System.out.println("Product Name: " + product.getName());
        System.out.println("Product Price: $" + product.getPrice());
    }

    public void showErrorMessage(String message) {
        System.out.println("Error: " + message);
    }
}

