public class CashRegister {
    private ProductDatabase productDatabase;
    private Display display;

    public CashRegister(ProductDatabase productDatabase, Display display) {
        this.productDatabase = productDatabase;
        this.display = display;
    }

    public void processProduct(int productId) {
        Product product = productDatabase.lookupProduct(productId);
        if (product != null) {
            display.showProductInfo(product);
        } else {
            display.showErrorMessage("Product not found.");
        }
    }
}



