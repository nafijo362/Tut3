import java.util.Scanner;

public class Keyboard {
    private final CashRegister cashRegister;

    public Keyboard(CashRegister cashRegister) {
        this.cashRegister = cashRegister;
    }

    public void enterProductID() {
        int i;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Product ID: ");
        int productId = scanner.nextInt();
        cashRegister.processProduct(productId);
    }
}

