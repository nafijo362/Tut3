import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
public class ProductDatabase {
    private Map<Integer, Product> products;
    public ProductDatabase(String filename) {
        products = new HashMap<>();
        loadProductsFromFile(filename);
    }
    private void loadProductsFromFile(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    int productId = Integer.parseInt(parts[0]);
                    String productName = parts[1];
                    double productPrice = Double.parseDouble(parts[2]);
                    products.put(productId, new Product(productName, productPrice));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Product lookupProduct(int productId) {
        return products.get(productId);
    }
}
